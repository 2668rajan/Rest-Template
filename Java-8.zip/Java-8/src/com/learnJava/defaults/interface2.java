package com.learnJava.defaults;

public interface interface2 {

    default void methodB(){
        System.out.println("method B");
    }
}
