package com.rajan.RestTemplateDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTemplateDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
