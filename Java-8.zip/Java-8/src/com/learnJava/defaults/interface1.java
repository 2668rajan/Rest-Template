package com.learnJava.defaults;

public interface interface1 {
  default void methodA(){
        System.out.println("methdod A");
    }
}
