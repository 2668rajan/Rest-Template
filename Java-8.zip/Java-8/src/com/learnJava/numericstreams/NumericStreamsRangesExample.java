package com.learnJava.numericstreams;

public class NumericStreamsRangesExample {

    public static void main(String[] args) {

    }
}
