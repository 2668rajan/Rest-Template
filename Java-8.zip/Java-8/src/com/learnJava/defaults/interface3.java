package com.learnJava.defaults;

public interface interface3 {

    default void methodC(){
        System.out.println("method C");
    }
}
